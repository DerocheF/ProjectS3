var searchData=
[
  ['data_30',['data',['../_liaison_serie_8ino.html#a433b1c9921d3b90f7c145c781a43f325',1,'LiaisonSerie.ino']]]
];
