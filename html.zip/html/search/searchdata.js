var indexSectionsWithContent =
{
  0: "bdfilmu",
  1: "l",
  2: "imu",
  3: "df",
  4: "bfm"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "defines"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Fichiers",
  2: "Fonctions",
  3: "Variables",
  4: "Macros"
};

